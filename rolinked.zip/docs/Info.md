# What's Rolinked?

Rolinked is a simple and fast Roblox Discord bot!

## What commands will it have?

  See, Rolinked's plan is to make a roblox bot which has:

- Verification
- Fun
- Other

## Invite Link?

[built-in extensions](https://vitepress.dev/guide/markdown)
