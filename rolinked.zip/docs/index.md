---
layout: home

hero:
  name: Rolinked
  text:  Simple Roblox Bot.
  tagline: Simple, powerful, and amazing roblox bot!
  actions:
    - theme: brand
      text: Get Started
      link: /Info
    - theme: alt
      text: View on GitHub
      link: https://github.com/orgs/Rolinked/
---
